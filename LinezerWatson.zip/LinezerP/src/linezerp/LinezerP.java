/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linezerp;

import com.ibm.watson.developer_cloud.service.security.IamOptions;
import com.ibm.watson.developer_cloud.visual_recognition.v3.VisualRecognition;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassResult;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifiedImage;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifiedImages;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifierResult;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifyOptions;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Arrays;

/**
 *
 * @author Xaibe
 */
public class LinezerP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        IamOptions options = new IamOptions.Builder()
	.apiKey("Kx-L2dUWnxSJXxIzVly3eSc33O_UH2yZrh5DgWnllO9M")
	.build();

VisualRecognition visualRecognition = new VisualRecognition("6.9.0", options);




VisualRecognition service = new VisualRecognition("2018-03-19", options);

InputStream imagesStream = new FileInputStream("metro.jfif");
ClassifyOptions classifyOptions = new ClassifyOptions.Builder()
	.imagesFile(imagesStream)
	.imagesFilename("metro.jfif")
	//.threshold((float) 0.6)
	.classifierIds(Arrays.asList("DefaultCustomModel_1040989811"))
	.build();

ClassifiedImages result = service.classify(classifyOptions).execute();
for(ClassifiedImage cosa : result.getImages()){
    for(ClassifierResult otro : cosa.getClassifiers()){
        for(ClassResult otra : otro.getClasses()){
            System.out.println(otra.getClassName()); // El numero al lado de la G indica el procentaje de gente en el anden
            System.out.println(otra.getScore());
        }
    }
}
    }
    
}
