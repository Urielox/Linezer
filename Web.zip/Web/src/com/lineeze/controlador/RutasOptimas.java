package com.lineeze.controlador;


import java.util.List;

import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.SelectorComposer;
import org.zkoss.zk.ui.select.Selectors;
import org.zkoss.zk.ui.select.annotation.Listen;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zul.Button;
import org.zkoss.zul.Cell;
import org.zkoss.zul.Combobox;
import org.zkoss.zul.Comboitem;
import org.zkoss.zul.Label;
import org.zkoss.zul.Messagebox;
import org.zkoss.zul.Row;
import org.zkoss.zul.Rows;
import org.zkoss.zul.Tabbox;
import org.zkoss.zul.Tabpanel;

import com.lineeze.modelo.Estacion;
import com.lineeze.servicio.GrafoManager;
import com.lineeze.servicio.LineaManager;

public class RutasOptimas  extends SelectorComposer<Component>{
	
	private static LineaManager lineaM = new LineaManager();
	private Tabpanel miPanel;
	private boolean slEaE1 = false;
	private boolean slEaE2 = false;
	private static GrafoManager eM = new GrafoManager();
	private String[] colores= new String[]{"",
			"rgb(240,109,162)","rgb(0,122,195)",
			"rgb(138,148,55)","rgb(136,200,188)",
			"rgb(255,224,26)","rgb(225,58,43)",
			"rgb(247,146,57)","rgb(0,155,103)",
			"rgb(94,51,26)","rgb(143,53,148)",
			"rgb(158,164,171)","rgb(178,155,89)"
											};
	private String selexione= "Seleccione Las estaciones";
	private String cls; 
	private String cls2; 

	@Wire
	private Tabbox tbbx;
	
	@Wire
	private Combobox lcboxEaE1;
	@Wire
	private Combobox cboxEaE1;
	@Wire
	private Combobox lcboxEaE2;
	@Wire
	private Combobox cboxEaE2;
	@Wire
	private Rows rEaE;
	@Wire
	private Label costoTiempo;
	@Wire
	private Label costoTransbordos;
	@Wire
	private Label costoEstaciones;
	@Wire
	private Button btnBuscarRutaEstacionAEstacion;
	
	
	
	
	private void marcaRutaEaE() {
		eM.getGrafo().dameCostos();
		costoTiempo.setValue(eM.getGrafo().getCostoTiempo());
		costoTransbordos.setValue(eM.getGrafo().getCostoTransbordos());
		costoEstaciones.setValue(eM.getGrafo().getCostoEstaciones());
		rEaE.getChildren().clear();
		
		for(Estacion e: eM.getRuta()) {
			Row fila = new Row();
			Cell dataEst = new Cell();
			Label labelE = new Label();
			Cell dataLin = new Cell();
			Label labelL = new Label();
			labelE.setValue(e.getEstacionNombre());
			labelL.setValue(e.getLineaNombre());
			dataEst.appendChild(labelE);
			cls = "linea" + e.getEstacionNombre();
			dataEst.setClass(cls);
			dataLin.appendChild(labelL);
			cls2 = "linea"+e.getLineaNombre();
			dataLin.setClass(cls2);
			fila.appendChild(dataEst);
			fila.appendChild(dataLin);
			rEaE.appendChild(fila);
		}
		
		
	}
	
	@Listen("onClick =#btnBuscarRutaEstacionAEstacion")
	public void buscaRutaEaE() {
		if(slEaE1 && slEaE2) {
		  try {
			  
		  
			String idcom1 = cboxEaE1.getSelectedItem().getValue().toString();
			
			String idcom2 = cboxEaE2.getSelectedItem().getValue().toString();
		
			idcom1 = idcom1.substring("cboxEaE1citemE".length());
		
			idcom2 = idcom2.substring("cboxEaE2citemE".length());
		
			int idor =Integer.parseInt(idcom1);
			int iddes =Integer.parseInt(idcom2);
			eM.getOrigen().setRelacionId(idor);
			eM.getDestino().setRelacionId(iddes);
			eM.estacionAEstacion();
			marcaRutaEaE();
		  }catch(Exception e) {
			  Messagebox.show(selexione);
		  }
		}
	}
	public void ponLineas(Tabpanel panel) {
		List<Component> lista;
		lista = Selectors.find(panel, ".Lin");
		Combobox combobox;
		Comboitem comboitem;
		int i;
		int j;
		int tamLis = lista.size();
		int tamEst;
		for(i = 0; i<tamLis; i++) {
			combobox = (Combobox)lista.get(i);
			if(combobox.getId().equals("lcboxEaE1")) {
				slEaE1 = true;
			} else if (combobox.getId().equals("lcboxEaE2")) {
				slEaE2 = true;
			}
			if(slEaE1 && slEaE2) {
				btnBuscarRutaEstacionAEstacion.setVisible(true);
				btnBuscarRutaEstacionAEstacion.setDisabled(false);
			} else {
				btnBuscarRutaEstacionAEstacion.setVisible(false);
				btnBuscarRutaEstacionAEstacion.setDisabled(true);
			}
			combobox.getChildren().clear();
			tamEst = lineaM.getLineas().size();
			for(j=1;j<tamEst;j++) {
				comboitem = new Comboitem();
				comboitem.setId(combobox.getId()+"citem"+lineaM.getLineas().get(j).getLineaId());
				comboitem.setClass("citem");
				comboitem.setLabel(Integer.toString(lineaM.getLineas().get(j).getLineaId()));
				cls = "linea" + lineaM.getLineas().get(j).getLineaNombre();
				comboitem.setClass(cls);
				combobox.appendChild(comboitem);
			}
		}
	}
	public void ponEstaciones(Combobox com) {
		int idLin = Integer.parseInt(com.getSelectedItem().getLabel());
		cls2 = "linea" + lineaM.getLineas().get(idLin).getLineaNombre();
		com.setClass(cls2);
		String nombreComboLin = com.getId();
		String nombreComboEst = nombreComboLin.substring(1);
		String nombreClase = "citemE";
		List<Component> lista;
		lista = Selectors.find(miPanel, "#"+nombreComboEst);
		Comboitem comboitem;
		if(lista.size() == 1) {
			Combobox comEst = (Combobox)lista.get(0);
			comEst.getChildren().clear();
			cls = "linea" + lineaM.getLineas().get(idLin).getLineaNombre();
			comEst.setClass(cls);
			for(Estacion e : lineaM.getLineas().get(idLin).getEstaciones()) {
				comboitem = new Comboitem();
				comboitem.setLabel(e.getEstacionNombre());
				comboitem.setId(comEst.getId()+nombreClase+e.getRelacionId());
				comboitem.setClass(nombreClase);
				comboitem.setValue(comEst.getId()+nombreClase+e.getRelacionId());
				comboitem.setClass(cls);
				comEst.appendChild(comboitem);
			}
			comEst.setSelectedIndex(0);
		}
		
	}
	public void cambiaColorEstac(Combobox com) {
		com.setClass(cls2);
	}
	
	@Listen("onSelect=#tbbx")
	public void cambiaRuteo() {
		Tabpanel panel = tbbx.getSelectedPanel();
		miPanel = panel;
		ponLineas(panel);
	}
	public void empieza() {
		btnBuscarRutaEstacionAEstacion.setVisible(false);
		btnBuscarRutaEstacionAEstacion.setDisabled(true);
		lineaM.traeNombres();
		cambiaRuteo();
	}
	@Override
	public void doAfterCompose(Component comp) throws Exception {
		super.doAfterCompose(comp);
		empieza();
	}
	
	
	
	
}
