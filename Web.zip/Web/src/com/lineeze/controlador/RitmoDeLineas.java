package com.lineeze.controlador;

import java.util.List;


import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.Selectors;
import org.zkoss.zk.ui.select.SelectorComposer;
import org.zkoss.zk.ui.select.annotation.Listen;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zul.Cell;
import org.zkoss.zul.Label;

import org.zkoss.zul.Row;
import org.zkoss.zul.Rows;

import org.zkoss.zul.Tabbox;
import org.zkoss.zul.Tabpanel;

import com.lineeze.servicio.LineaManager;

public class RitmoDeLineas extends SelectorComposer<Component>{
	@Wire
	private Tabbox tbbx;
	
	
	public void escribeDatosLinea(Tabpanel panel, LineaManager linea) {
		List<Component> lista;
		lista = Selectors.find(panel, ".colorLinea");
		Label label;
		if(lista.size() == 1) {
			label = (Label)lista.get(0);
			label.setValue(linea.getLinea().getLineaColor());
		}
		lista = Selectors.find(panel, ".cantEstaciones");
		if(lista.size() == 1) {
			label = (Label)lista.get(0);
			label.setValue(Integer.toString(linea.getLinea().getEstaciones().size()));
		}
		lista = Selectors.find(panel, ".promedioTiempos");
		if(lista.size() == 1) {
			label = (Label)lista.get(0);
			label.setValue(Long.toString(linea.getLinea().getTiempoPromedio()));
		}
	}
	public void muestraEstaciones(Tabpanel panel, LineaManager linea) {
		List<Component> lista;
		lista = Selectors.find(panel, ".filas");
		Rows filas;
		if(lista.size() == 1) {
			filas = (Rows)lista.get(0);
			lista = Selectors.find(panel, ".fila");
			
			int i;
			int tamanio = linea.getLinea().getTiempoVuelta().size();
			String alineacion= "center";
			String claseDeFila = "fila";
			Row fila;
			Cell celda;
			Label label;
			if(lista.isEmpty()) {
				filas.getChildren().clear();
				for(i = 0 ; i < tamanio; i++ ) {
					/// insert an station
					fila = new Row();
					fila.setClass(claseDeFila);
						celda = new Cell();
							label = new Label();
							label.setValue(linea.getLinea().getEstaciones().get(i).getEstacionNombre());
							celda.setColspan(3);
							celda.setAlign(alineacion);
							celda.appendChild(label);
							fila.appendChild(celda);
							filas.appendChild(fila);
					
					fila = new Row();
					fila.setClass(claseDeFila);
						/// insert a time
						celda = new Cell();
							label = new Label();
							label.setValue(Long.toString(linea.getLinea().getTiempoVuelta().get(i)));
							celda.setAlign(alineacion);
							celda.appendChild(label);
							fila.appendChild(celda);
						/// insert a void cell
						celda = new Cell();
						fila.appendChild(celda);
					/// insert a time
						celda = new Cell();
							label = new Label();
							label.setValue(Long.toString(linea.getLinea().getTiempoIda().get(i)));
							celda.setAlign(alineacion);
							celda.appendChild(label);
							fila.appendChild(celda);
							filas.appendChild(fila);
				}
				fila = new Row();
				fila.setClass(claseDeFila);
					celda = new Cell();
						label = new Label();
						label.setValue(linea.getLinea().getEstaciones().get(i).getEstacionNombre());
						celda.setColspan(3);
						celda.setAlign(alineacion);
						celda.appendChild(label);
						fila.appendChild(celda);
						filas.appendChild(fila);
			} else {
				/// if it does not empty
				for(i = 0 ; i < tamanio; i++ ) {
					fila = (Row)lista.get((i*2)+1);
					///left
					celda = (Cell)fila.getChildren().get(0);
					label = (Label)celda.getChildren().get(0);
					label.setValue(Long.toString(linea.getLinea().getTiempoVuelta().get(i)));
					///right
					celda = (Cell)fila.getChildren().get(2);
					label = (Label)celda.getChildren().get(0);
					label.setValue(Long.toString(linea.getLinea().getTiempoIda().get(i)));
				}
			}
		}
	}
	
	public void muestraLinea(Tabpanel panel, LineaManager linea) {
		escribeDatosLinea(panel, linea);
		muestraEstaciones(panel, linea);
	}
	
	@Listen("onSelect=#tbbx")
	public void cambiaLinea() {
		String lineaNombre;
		Tabpanel panel = tbbx.getSelectedPanel();
		lineaNombre = panel.getId();
		lineaNombre = lineaNombre.substring(8);
		LineaManager linea = new LineaManager(20, lineaNombre);
		muestraLinea(panel, linea);
	}
	
	@Override
	public void doAfterCompose(Component comp) throws Exception {
		super.doAfterCompose(comp);
		cambiaLinea();
	}
	
	@Listen("onTimer = #timo")
	public void haz() {
		cambiaLinea();
	}
	
}
		

