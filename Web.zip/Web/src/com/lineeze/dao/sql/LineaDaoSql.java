package com.lineeze.dao.sql;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.lineeze.dao.LineaDAO;
import com.lineeze.database.Conexion;
import com.lineeze.modelo.Estacion;
import com.lineeze.modelo.Linea;

public class LineaDaoSql implements LineaDAO {

	private CallableStatement cstmt;
	private ResultSet rs;
	private Conexion conexion;
	private Linea linea;
	
	private static final String TRAEESTACIONESDELINEA = "call TRAEESTACIONESDELINEA(?,?)";
	private static final String TRAEDATOSLINEA = "call TRAEDATOSLINEA(?,?)";
	private static final String TRAETIEMPOSDELINEA = "call traetiemposdelinea(?,?)";
	private static final String TRAELINEASTODAS = "call traelineasTodas()";
	private static final String TRAEESTALINNOMBRES = "call traeestalinNombres()";
	private static final String NCOLOR = "color";
	private static final String NNOM = "nombre";
	
	
	public LineaDaoSql() {
		this.linea = new Linea();
		this.cstmt = null;
		this.rs = null;
		this.conexion = new Conexion();
	}
	
	

	@Override
	public Linea traeObjeto(int criterio, String prametro) {
		Estacion estacion;
		Connection cnx = null;
		linea = new Linea();
		try {
			
			cnx = conexion.crearConexion();
			/* bring what line it is*/
			cstmt = cnx.prepareCall(TRAEDATOSLINEA);
			cstmt.setInt(1, criterio);
			cstmt.setString(2, prametro);
			rs = cstmt.executeQuery();
						
			if(rs.next()) {
				linea.setLineaId((int)rs.getInt("id"));
				linea.setLineaColor((String)rs.getString(NCOLOR));
				linea.setLineaNombre((String)rs.getString(NNOM));
			}
			
			cstmt = cnx.prepareCall(TRAEESTACIONESDELINEA);
			cstmt.setInt(1, criterio);
			cstmt.setString(2, prametro);
			rs = cstmt.executeQuery();
			 int relacionId;
			 int estacionId;
			 int lineaId = linea.getLineaId();
			 String estacionNombre;
			 String lineaNombre = linea.getLineaNombre();
			
			while(rs.next()) {
				estacionId = rs.getInt("estacionId");
				estacionNombre = rs.getString("estacionNombre");
				relacionId = rs.getInt("relacionId");
				
				
				estacion = new Estacion(
						relacionId,
						estacionId,
						lineaId,
						estacionNombre,
						lineaNombre);
						
				linea.getEstaciones().add(estacion);
			}
			
			cstmt = cnx.prepareCall(TRAETIEMPOSDELINEA);
			cstmt.setInt(1, criterio);
			cstmt.setString(2, prametro);
			rs = cstmt.executeQuery();
			int cuantos =0;
			Long cida;
			Long cvenida;
			Long suma=(long) 0;
			while(rs.next()) {
				cida = rs.getLong("ida");
				cvenida = rs.getLong("vuelta");
				linea.getTiempoIda().add(cida);
				linea.getTiempoVuelta().add(cvenida);
				suma+= cida;
				suma+= cvenida;
				cuantos++;
			}
			cuantos*=2;
			if(cuantos>0) suma/=cuantos;
			
			linea.setTiempoPromedio(suma);
			rs.close();
			cstmt.close();
			cnx.close();
			conexion.cerrarConexion();
		}catch(Exception e) {
			e.getStackTrace();
		}
		return linea;
	}

	@Override
	public int actualizar(Linea o) {
		return 0;
	}

	public List<Linea> traeSoloNombres() {
		List<Linea> lineas = new ArrayList<>();
		Connection cnx = null;
		try {
			
			cnx = conexion.crearConexion();
			/* bring what line it is*/
			cstmt = cnx.prepareCall(TRAELINEASTODAS);
			rs = cstmt.executeQuery();
			linea = new Linea();
			lineas.add(linea);
			while(rs.next()) {
				linea = new Linea();
				linea.setLineaId((int)rs.getInt("id"));
				linea.setLineaColor((String)rs.getString(NCOLOR));
				linea.setLineaNombre((String)rs.getString(NNOM));
				lineas.add(linea);
			}
			
			/* bring what line it is*/
			cstmt = cnx.prepareCall(TRAEESTALINNOMBRES);
			rs = cstmt.executeQuery();
			
			Estacion etemp;
			int relacionId=0;
			String estacionNombre="";
			int lineaId=0;
			while(rs.next()){
				relacionId = rs.getInt("relacionId");
				estacionNombre = rs.getString("estacionNombre");
				lineaId = rs.getInt("lineaId");
				etemp = new Estacion();
				etemp.setRelacionId(relacionId);
				etemp.setEstacionNombre(estacionNombre);
				etemp.setLineaId(lineaId);
				lineas.get(lineaId).getEstaciones().add(etemp);
			}
			rs.close();
			cstmt.close();
			cnx.close();
			conexion.cerrarConexion();
		}catch(Exception e) {
			e.getStackTrace();
		}
		return lineas;
	}
	@Override
	public List<Linea> traeObjetos(int criterio, String parametro) {
		List<Linea> lineas = new ArrayList<>();
		Connection cnx = null;
		try {
			
			cnx = conexion.crearConexion();
			/* bring what line it is*/
			cstmt = cnx.prepareCall(TRAELINEASTODAS);
			rs = cstmt.executeQuery();
			linea = new Linea();
			lineas.add(linea);
			while(rs.next()) {
				linea = new Linea();
				linea.setLineaId((int)rs.getInt("id"));
				linea.setLineaColor((String)rs.getString(NCOLOR));
				linea.setLineaNombre((String)rs.getString(NNOM));
				lineas.add(linea);
			}
			rs.close();
			cstmt.close();
			cnx.close();
			conexion.cerrarConexion();
			int tamanio = lineas.size();
			int i=0;
			Linea xd;
			
			for(i=1; i<tamanio; i++) {
				xd = traeObjeto(20,lineas.get(i).getLineaNombre());
				lineas.set(i,xd);
			}
		}catch(Exception e) {
			e.getStackTrace();
		}
		return lineas;
	}

}
