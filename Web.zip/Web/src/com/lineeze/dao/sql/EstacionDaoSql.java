package com.lineeze.dao.sql;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.lineeze.dao.EstacionDAO;
import com.lineeze.database.Conexion;
import com.lineeze.modelo.Estacion;

public class EstacionDaoSql implements EstacionDAO {
	
	private CallableStatement cstmt;
	private ResultSet rs;
	private Conexion conexion;
	 
	
	private static final String TRAEESTACIONES = "call traeestalinTodas()";
	
	
	
	
	public EstacionDaoSql() {
		this.cstmt = null;
		this.rs = null;
		this.conexion = new Conexion();
	}



	@Override
	public List<Estacion> traeObjetos(int criterio, String parametro) {
		List<Estacion> estaciones = new ArrayList<>();
		Connection cnx = null;
		Estacion estacion;
		try {
			
			cnx = conexion.crearConexion();
			cstmt = cnx.prepareCall(TRAEESTACIONES);
			rs = cstmt.executeQuery();
			estacion = new Estacion();
			estaciones.add(estacion);
			while(rs.next()) {
				estacion = new Estacion(
						(int)rs.getInt("relacionId"),
						(int)rs.getInt("estacionId"),
						(int)rs.getInt("lineaId"),
						(String)rs.getString("estacionNombre"),
						(String)rs.getString("lineaNombre"));
				estaciones.add(estacion);
			}
			rs.close();
			cstmt.close();
			cnx.close();
			conexion.cerrarConexion();
		}catch(Exception e) {
			e.getStackTrace();
		}
		return estaciones;
	}



	@Override
	public int actualizar(Estacion o) {
		return 0;
	}



	@Override
	public Estacion traeObjeto(int criterio, String prametro) {
		return null;
	}



	

	

}
