package com.lineeze.dao.sql;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lineeze.dao.AristaDAO;
import com.lineeze.database.Conexion;
import com.lineeze.modelo.Arista;

public class AristaDaoSql implements AristaDAO{
	
	private CallableStatement cstmt;
	private ResultSet rs;
	private Conexion conexion;
	  

	private static final String TRAEADYACENCIASTODAS = "call traeAdyacenciasTodas()";
	private static final String ACTUALIZATIEMPOEAE = "call actualizaTiempoEaE(?,?,?,?,?)";
	private static final String ACTUALIZATIEMPOEAEPORNOMBRES = "call actualizaTiempoEaEporNombres(?,?,?,?,?)";
	private static final String ACTUALIZATIEMPOEAEPORIDR = "call actualizaTiempoEaEporIDR(?,?,?)";
	
	public AristaDaoSql() {
		super();
		this.cstmt = null;
		this.rs = null;
		this.conexion = new Conexion();
	}

	
	@Override
	public int actualizar(Arista o) {
		return 0;
	}

	@Override
	public Arista traeObjeto(int criterio, String prametro) {
		return null;
	}
	public void actualizar(int ideor,int idlinor,int idedes,int idlindes,long tempo) {
		Connection cnx = null;
		cnx = conexion.crearConexion();
		try {
			cstmt = cnx.prepareCall(ACTUALIZATIEMPOEAE);
			cstmt.setInt(1, ideor);
			cstmt.setInt(2, idlinor);
			cstmt.setInt(3, idedes);
			cstmt.setInt(4, idlindes);
			cstmt.setLong(5, tempo);
			cstmt.execute();
		} catch (SQLException e) {
			e.getStackTrace();
		}
	}
	public void actualizar(String ideor,String idlinor,String idedes,String idlindes,long tempo) {
		Connection cnx = null;
		cnx = conexion.crearConexion();
		try {
			cstmt = cnx.prepareCall(ACTUALIZATIEMPOEAEPORNOMBRES);
			cstmt.setString(1, ideor);
			cstmt.setString(2, idlinor);
			cstmt.setString(3, idedes);
			cstmt.setString(4, idlindes);
			cstmt.setLong(5, tempo);
			cstmt.execute();
		} catch (SQLException e) {
			e.getStackTrace();
		}
	}
	public void actualizar(int ideor,int idedes,long tempo) {
		Connection cnx = null;
		cnx = conexion.crearConexion();
		try {
			cstmt = cnx.prepareCall(ACTUALIZATIEMPOEAEPORIDR);
			cstmt.setInt(1, ideor);
			cstmt.setInt(2, idedes);
			cstmt.setLong(3, tempo);
			cstmt.execute();
		} catch (SQLException e) {
			e.getStackTrace();
		}
	}
	@Override
	public List<Arista> traeObjetos(int criterio, String parametro) {
		List<Arista> aristas = new ArrayList<>();
		Arista arista;
		Connection cnx = null;
		 long tiempo ;
		 int relacionRRId;
		 int relacionRRIdOrigen;
		 int relacionRRIdDestino;
		try {
			
			cnx = conexion.crearConexion();
			cstmt = cnx.prepareCall(TRAEADYACENCIASTODAS);
			rs = cstmt.executeQuery();
			
			while(rs.next()) {
				tiempo = rs.getLong("tiempo");
				relacionRRId = rs.getInt("relacionRRId");
				relacionRRIdOrigen = rs.getInt("relacionRRIdOrigen");
				relacionRRIdDestino = rs.getInt("relacionRRIdDestino");
				arista = new Arista(tiempo, relacionRRId, relacionRRIdOrigen, relacionRRIdDestino);
				aristas.add(arista);
			}
			rs.close();
			cstmt.close();
			cnx.close();
			conexion.cerrarConexion();
		}catch(Exception e) {
			e.getStackTrace();
		}
		return aristas;
	}

}
