package com.lineeze.dao;

import com.lineeze.modelo.Estacion;

public interface EstacionDAO extends DAO<Estacion> {

}
