package com.lineeze.dao;

import java.util.List;

public interface DAO<O>{
	int actualizar(O o);
	O traeObjeto(int criterio, String prametro);
	List<O> traeObjetos(int criterio, String parametro);
}

