package com.lineeze.dao;

import com.lineeze.modelo.Arista;

public interface AristaDAO extends DAO<Arista>{

}
