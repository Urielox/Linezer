package com.lineeze.dao;

import com.lineeze.modelo.Linea;

public interface LineaDAO extends DAO<Linea>{

}
