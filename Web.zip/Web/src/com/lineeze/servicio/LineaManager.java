package com.lineeze.servicio;

import java.util.ArrayList;
import java.util.List;

import com.lineeze.dao.sql.LineaDaoSql;
import com.lineeze.modelo.Linea;

public class LineaManager {
	private Linea linea;
	private List<Linea> lineas;
	private LineaDaoSql lineadaosql;
	
	public void traeLineasTodas() {
		this.lineas = new ArrayList<>();
		this.lineas = lineadaosql.traeObjetos(0, "");
	}
	
	public void traeLinea(int criterio, String parametro) {
		this.lineadaosql = new LineaDaoSql();
		this.linea = lineadaosql.traeObjeto(criterio, parametro);
	}
	public void traeNombres() {
		this.lineadaosql = new LineaDaoSql();
		this.lineas = lineadaosql.traeSoloNombres();
	}
	public LineaManager(int criterio, String parametro) {
		super();	
		this.lineadaosql = new LineaDaoSql();
		this.linea = lineadaosql.traeObjeto(criterio, parametro);
	}
	
	public LineaManager() {
		super();
		this.linea = new Linea();
		this.lineadaosql = new LineaDaoSql();
		this.lineas = new ArrayList<>();
		this.lineas = lineadaosql.traeSoloNombres();
	}
	public LineaManager(Linea l) {
		super();
		this.linea = l;
	}

	public Linea getLinea() {
		return linea;
	}

	public void setLinea(Linea linea) {
		this.linea = linea;
	}
	
	public List<Linea> getLineas() {
		return lineas;
	}

	public void setLineas(List<Linea> lineas) {
		this.lineas = lineas;
	}

	public LineaDaoSql getLineadaosql() {
		return lineadaosql;
	}

	public void setLineadaosql(LineaDaoSql lineadaosql) {
		this.lineadaosql = lineadaosql;
	}

	@Override
	public String toString() {
		return "LineaManager [linea=" + linea + "]";
	}
	
	
}
