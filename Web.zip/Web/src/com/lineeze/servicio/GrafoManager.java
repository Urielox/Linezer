package com.lineeze.servicio;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.lineeze.modelo.*;

public class GrafoManager{
	private Grafo grafo;
	private Estacion origen;
	private Estacion destino;
	
	private List<Estacion> ruta;
	
	
	
	public List<Estacion> estacionAEstacion(Estacion o, Estacion d){
		grafo.generaConexiones();
		ruta = new ArrayList<>();
		ruta = grafo.estacionAEstacion(o, d);
		return ruta;
	}
	public void estacionAEstacion(){
		grafo.generaConexiones();
		ruta = new ArrayList<>();
		ruta = grafo.estacionAEstacion(origen, destino);
	}
	public GrafoManager() {
		this.grafo = new Grafo();
		this.origen = new Estacion();
		this.destino = new Estacion();
		this.ruta = new ArrayList<>();
	}
	public void restaura() {
		this.origen = new Estacion();
		this.destino = new Estacion();
		this.ruta = new ArrayList<>();
	}
	public Grafo getGrafo() {
		return grafo;
	}
	public void setGrafo(Grafo grafo) {
		this.grafo = grafo;
	}
	public Estacion getOrigen() {
		return origen;
	}
	public void setOrigen(Estacion origen) {
		this.origen = origen;
	}
	public Estacion getDestino() {
		return destino;
	}
	public void setDestino(Estacion destino) {
		this.destino = destino;
	}
	public List<Estacion> getRuta() {
		return ruta;
	}
	public void setRuta(List<Estacion> ruta) {
		this.ruta = ruta;
	}
	
	public String segATiempo(long tem) {
		long horas;
		long minutos;
		long seg;
		long t = tem;
		seg = t%60;
		t/=60;
		minutos = t%60;
		t/=60;
		horas = t;
		return ("\t\t"+horas+ " Hrs. \t\t" + minutos + " Mins. \t\t" + seg + " segs. " );
	}
}
