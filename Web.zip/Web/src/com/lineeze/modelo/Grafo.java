package com.lineeze.modelo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;

import com.lineeze.dao.sql.AristaDaoSql;
import com.lineeze.dao.sql.EstacionDaoSql;

public class Grafo {
	private List<Arista> aristas;
	private List<List<Conetzion> >conexiones;
	private List<Estacion> estaciones;
	private String datosTiempo ="";
	private String costoTiempo ="" ;
	private String costoTransbordos ="";
	private String costoEstaciones ="";
	private int transbordosHechos;
	private int estacionesRecorridas;
	private int cantEstaciones = 195;
	private long tiempoTotal;
	private int[] visitados;
	private int[] orden = new int[cantEstaciones+4];
	private int[] aglomeracion = new int[cantEstaciones+4];
	private long[][] matrizAdyacencias = new long[cantEstaciones+4][cantEstaciones+4];
	private long[][] tiemposMinimos = new long[cantEstaciones+4][cantEstaciones+4];
	
	
	public Grafo() {
		estaciones = new ArrayList<>();
		estaciones = new EstacionDaoSql().traeObjetos(0, "");
		visitados = new int[cantEstaciones+4];
		generaConexiones();
	}
	public void generaConexiones() {
		conexiones = new ArrayList<>();
		Conetzion conexion;
		iniciaConexiones();
		aristas = new AristaDaoSql().traeObjetos(0,"");
		limpiaMatrizDeAdyacencias();
		for(Arista a : aristas) {
			conexion = new Conetzion();
			conexion.setTiempo(a.getTiempo());
			conexion.setSiguienteId(a.getRelacionRRIdDestino());
			conexiones.get(a.getRelacionRRIdOrigen()).add(conexion);
			matrizAdyacencias[a.getRelacionRRIdOrigen()][a.getRelacionRRIdDestino()] = a.getTiempo();
		}
	}
	private void  limpiaMatrizDeAdyacencias() {
		for(int x = 0; x < cantEstaciones+3; x++) {
			for(int y = 0; y < cantEstaciones+3; y++) {
				matrizAdyacencias[x][y] = -1;
			}
		}
	}
	public void  limpiaTiemposMinimos() {
		for(int x = 1; x <= cantEstaciones; x++) {
			for(int y = 1; y <= cantEstaciones; y++) {
				if(matrizAdyacencias[x][y] <0 ) {
					tiemposMinimos[x][y] = Long.MAX_VALUE/4;
				} else {
					tiemposMinimos[x][y] = matrizAdyacencias[x][y];
				}
			}
		}
	}
	
	private void iniciaConexiones() {
		conexiones = new ArrayList<>();
		for(int x=0;x<=cantEstaciones+1;x++) {
			conexiones.add(new ArrayList<>());
			aglomeracion[x] = 1;
		}
	}
	private void limpiaVisitados() {
		for(int x=0;x<=cantEstaciones+1;x++) {
			visitados[x] = -1;
		}
	}

	private void ponTodo() {
		estaciones = new ArrayList<>();
		estaciones = new EstacionDaoSql().traeObjetos(0, "");
		visitados = new int[cantEstaciones+4];
		generaConexiones();
	}
	
	private void sacaAglomeracion(int esta) {
		///Pos se supone aqui va metido lo de IBM Watson
	}
	
	
	
	public boolean baja(long costo,Set<Integer> grupo,int fin,int anterior) {
		boolean jala = false;
		if(grupo.isEmpty()) {
			long act = costo+tiemposMinimos[anterior][fin];
			if(act < tiempoTotal) {
				tiempoTotal = act;
				orden[0] = anterior;
				return true;
			}
		} else {
			for(int es : grupo) {
				Set<Integer> g = new HashSet<>(grupo);
				g.remove(es);
				long act = costo + tiemposMinimos[anterior][es];
				if(act < tiempoTotal) {
					boolean aver = baja(act, g, fin, es);
					if(aver) {
						orden[grupo.size()] = anterior;
						jala = true;
					}
				}
			}
		}
		return jala;
	}
	
	
	

	

	private void dijsktraMarca(Estacion origen, Estacion destino){
		
		PriorityQueue<Conetzion> cola = new PriorityQueue<>();
		limpiaVisitados();
		
		Conetzion inicio = new Conetzion();
		inicio.setTiempo((long) 0);
		inicio.setSiguienteId(origen.getRelacionId());
		inicio.setAnteriorId(origen.getRelacionId());
		Conetzion fin = new Conetzion();
		fin.setTiempo((long) 0);
		fin.setSiguienteId(destino.getRelacionId());
		
		cola.add(inicio);
		Conetzion actual;
		Conetzion nueva;
		while(!cola.isEmpty()) {
			actual = new Conetzion(cola.peek()); cola.poll();
			if(visitados[actual.getSiguienteId()] == -1) {
							
				visitados[actual.getSiguienteId()] = actual.getAnteriorId();
				
				if(actual.getSiguienteId() == fin.getSiguienteId()) {
					tiempoTotal = actual.getTiempo();
					break;
				}
			
				for(Conetzion c : conexiones.get(actual.getSiguienteId())) {
					if(visitados[c.getSiguienteId()] == -1) {
						nueva = new Conetzion();
						nueva.setAnteriorId(actual.getSiguienteId());
						nueva.setSiguienteId(c.getSiguienteId());
						int agropecuario = 1;
						if(estaciones.get(nueva.getAnteriorId()).getLineaId() == estaciones.get(nueva.getSiguienteId()).getLineaId()) {
							agropecuario = aglomeracion[nueva.getSiguienteId()];	
						}
						nueva.setTiempo(actual.getTiempo()+(c.getTiempo()*agropecuario));
						cola.add(nueva);
					}
				}
			}
		}
		
	}
	public List<Estacion> estacionAEstacion(Estacion origen, Estacion destino){
		ponTodo();
		dijsktraMarca(origen,destino);
		
		List<Estacion> estas = new ArrayList<>();
		Estacion esta;
		Estacion anterior;
		anterior = new Estacion();
		anterior.setRelacionId(-1);
		
		
		int lugar = destino.getRelacionId();
		int contador = 0;
		estacionesRecorridas = 0;
		transbordosHechos = 0;
		while(lugar != origen.getRelacionId()) {
			
			
			esta = new Estacion(estaciones.get(lugar));
			estas.add(esta);
			lugar = visitados[esta.getRelacionId()];
			if(contador >0 && (anterior.getEstacionId() == esta.getEstacionId())) {
				transbordosHechos++;
			} else {
				estacionesRecorridas++;
			}
			anterior = esta;
			contador++;
		}
		
		esta = new Estacion(estaciones.get(lugar));
		estas.add(esta);
		if(contador >0 && (anterior.getEstacionId() == esta.getEstacionId())) {
			transbordosHechos++;
		} else {
			estacionesRecorridas++;
		}
		
		Collections.reverse(estas);
		
		return estas;
	}
	public List<Arista> getAristas() {
		return aristas;
	}
	public void setAristas(List<Arista> aristas) {
		this.aristas = aristas;
	}
	public List<List<Conetzion>> getConexiones() {
		return conexiones;
	}
	public void setConexiones(List<List<Conetzion>> conexiones) {
		this.conexiones = conexiones;
	}
	public int[] getVisitados() {
		return visitados;
	}
	public void setVisitados(int[] visitados) {
		this.visitados = visitados;
	}
	
	public List<Estacion> getEstaciones() {
		return estaciones;
	}
	public void setEstaciones(List<Estacion> estaciones) {
		this.estaciones = estaciones;
	}
	public long getTiempoTotal() {
		return tiempoTotal;
	}
	public void setTiempoTotal(long tiempoTotal) {
		this.tiempoTotal = tiempoTotal;
	}
	public int getTransbordosHechos() {
		return transbordosHechos;
	}
	public void setTransbordosHechos(int transbordosHechos) {
		this.transbordosHechos = transbordosHechos;
	}
	public int getEstacionesRecorridas() {
		return estacionesRecorridas;
	}
	public void setEstacionesRecorridas(int estacionesRecorridas) {
		this.estacionesRecorridas = estacionesRecorridas;
	}
	@Override
	public String toString() {
		return "Grafo [aristas=" + aristas + ", conexiones=" + conexiones + ", visitados=" + Arrays.toString(visitados)
				+ "]";
	}
	public String dameCostos() {
		long horas;
		long minutos;
		long seg;
		long t;
		t = tiempoTotal;
		seg = t%60;
		t/=60;
		minutos = t%60;
		t/=60;
		horas = t;
		String tomado = "\t\tHrs: " + horas + "\t\t Mins: " + minutos + "\t\t segs: " + seg;
		datosTiempo = tomado;
		costoTiempo = "Tiempo Estimado: "+ horas + " Hrs. \t\t" + minutos + " Mins. \t\t" + seg+ " Segs.";
		costoEstaciones = "Estaciones recorridas: " + estacionesRecorridas;
		costoTransbordos = "Transbordos realizados : " + transbordosHechos;
		return "\t Tiempo Estimado: " + tomado + "  \n"
			 + "\t Transbordos realizados : " + transbordosHechos + " \n"
			 + "\t Estaciones recorridas : " + estacionesRecorridas + " \n";
	}
	
	public String getDatosTiempo() {
		return datosTiempo;
	}
	public void setDatosTiempo(String datosTiempo) {
		this.datosTiempo = datosTiempo;
	}
	public String getCostoTiempo() {
		return costoTiempo;
	}
	public void setCostoTiempo(String costoTiempo) {
		this.costoTiempo = costoTiempo;
	}
	public String getCostoTransbordos() {
		return costoTransbordos;
	}
	public void setCostoTransbordos(String costoTransbordos) {
		this.costoTransbordos = costoTransbordos;
	}
	public String getCostoEstaciones() {
		return costoEstaciones;
	}
	public void setCostoEstaciones(String costoEstaciones) {
		this.costoEstaciones = costoEstaciones;
	}
	public int getCantEstaciones() {
		return cantEstaciones;
	}
	public void setCantEstaciones(int cantEstaciones) {
		this.cantEstaciones = cantEstaciones;
	}
	
	public long[][] getMatrizAdyacencias() {
		return matrizAdyacencias;
	}
	public void setMatrizAdyacencias(long[][] matrizAdyacencias) {
		this.matrizAdyacencias = matrizAdyacencias;
	}
	public long[][] getTiemposMinimos() {
		return tiemposMinimos;
	}
	public void setTiemposMinimos(long[][] tiemposMinimos) {
		this.tiemposMinimos = tiemposMinimos;
	}
	
	
}
