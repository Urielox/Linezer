package com.lineeze.modelo;

public class Arista {
	private long tiempo ;
	private int relacionRRId;
	private int relacionRRIdOrigen;
	private int relacionRRIdDestino;
	public Arista(long tiempo, int relacionRRId, int relacionRRIdOrigen, int relacionRRIdDestino) {
		super();
		this.tiempo = tiempo;
		this.relacionRRId = relacionRRId;
		this.relacionRRIdOrigen = relacionRRIdOrigen;
		this.relacionRRIdDestino = relacionRRIdDestino;
	}
	public Arista() {
		
	}
	public long getTiempo() {
		return tiempo;
	}
	public void setTiempo(long tiempo) {
		this.tiempo = tiempo;
	}
	public int getRelacionRRId() {
		return relacionRRId;
	}
	public void setRelacionRRId(int relacionRRId) {
		this.relacionRRId = relacionRRId;
	}
	public int getRelacionRRIdOrigen() {
		return relacionRRIdOrigen;
	}
	public void setRelacionRRIdOrigen(int relacionRRIdOrigen) {
		this.relacionRRIdOrigen = relacionRRIdOrigen;
	}
	public int getRelacionRRIdDestino() {
		return relacionRRIdDestino;
	}
	public void setRelacionRRIdDestino(int relacionRRIdDestino) {
		this.relacionRRIdDestino = relacionRRIdDestino;
	}
	@Override
	public String toString() {
		return "Arista [tiempo=" + tiempo + ", relacionRRId=" + relacionRRId + ", relacionRRIdOrigen="
				+ relacionRRIdOrigen + ", relacionRRIdDestino=" + relacionRRIdDestino + "]";
	}
	
	
}
