package com.lineeze.modelo;

public class Conetzion implements Comparable<Conetzion>{
	private Long tiempo;
	private int siguienteId;
	private int anteriorId;
	
	
	public Conetzion() {
		super();
	}

	public Conetzion(Conetzion c) {
		this.tiempo = c.getTiempo();
		this.siguienteId = c.getSiguienteId();
		this.anteriorId = c.getAnteriorId();
	}
	
	public Conetzion(Long tiempo, int siguienteId, int anteriorId) {
		super();
		this.tiempo = tiempo;
		this.siguienteId = siguienteId;
		this.anteriorId = anteriorId;
	}
	public Long getTiempo() {
		return tiempo;
	}
	public void setTiempo(Long tiempo) {
		this.tiempo = tiempo;
	}
	public int getSiguienteId() {
		return siguienteId;
	}
	public void setSiguienteId(int siguienteId) {
		this.siguienteId = siguienteId;
	}
	public int getAnteriorId() {
		return anteriorId;
	}
	public void setAnteriorId(int anteriorId) {
		this.anteriorId = anteriorId;
	}
	@Override
	public String toString() {
		return "Conetzion [tiempo=" + tiempo + ", siguienteId=" + siguienteId + ", anteriorId=" + anteriorId + "]";
	}
	@Override
	public int compareTo(Conetzion otra) {
		return Long.compare(this.tiempo, otra.getTiempo());
	}

	@Override
	public boolean equals(Object arg0) {
		return super.equals(arg0);
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}
	

	
	
}
