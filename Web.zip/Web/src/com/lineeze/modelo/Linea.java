package com.lineeze.modelo;


import java.util.ArrayList;
import java.util.List;

public class Linea {
	private int lineaId;
	private long tiempoPromedio;
	private String lineaNombre;
	private String lineaColor;
	private List<Estacion> estaciones;
	private List<Long> tiempoIda;
	private List<Long> tiempoVuelta;
	
	
	public Linea() {
		this.lineaId = 0;
		this.tiempoPromedio = (long) 0;
		this.lineaNombre = "";
		this.lineaColor = "";
		this.estaciones = new ArrayList<>();
		this.tiempoIda = new ArrayList<>();
		this.tiempoVuelta = new ArrayList<>();
	}
	
	public Linea(int lineaId, Long tiempoPromedio, String lineaNombre, String lineaColor, List<Estacion> estaciones,
			List<Long> tiempoIda, List<Long> tiempoVuelta) {
		super();
		this.lineaId = lineaId;
		this.tiempoPromedio = tiempoPromedio;
		this.lineaNombre = lineaNombre;
		this.lineaColor = lineaColor;
		this.estaciones = estaciones;
		this.tiempoIda = tiempoIda;
		this.tiempoVuelta = tiempoVuelta;
	}





	public String getLineaColor() {
		return lineaColor;
	}

	public void setLineaColor(String lineaColor) {
		this.lineaColor = lineaColor;
	}





	public Long getTiempoPromedio() {
		return tiempoPromedio;
	}
	public void setTiempoPromedio(Long tiempoPromedio) {
		this.tiempoPromedio = tiempoPromedio;
	}
	public int getLineaId() {
		return lineaId;
	}
	public void setLineaId(int lineaId) {
		this.lineaId = lineaId;
	}
	public String getLineaNombre() {
		return lineaNombre;
	}
	public void setLineaNombre(String lineaNombre) {
		this.lineaNombre = lineaNombre;
	}
	public List<Estacion> getEstaciones() {
		return estaciones;
	}
	public void setEstaciones(List<Estacion> estaciones) {
		this.estaciones = estaciones;
	}
	public List<Long> getTiempoIda() {
		return tiempoIda;
	}
	public void setTiempoIda(List<Long> tiempoIda) {
		this.tiempoIda = tiempoIda;
	}
	public List<Long> getTiempoVuelta() {
		return tiempoVuelta;
	}
	public void setTiempoVuelta(List<Long> tiempoVuelta) {
		this.tiempoVuelta = tiempoVuelta;
	}

	@Override
	public String toString() {
		return "Linea [lineaId=" + lineaId + ", tiempoPromedio=" + tiempoPromedio + ", lineaNombre=" + lineaNombre
				+ ", lineaColor=" + lineaColor + ", estaciones=" + estaciones + ", tiempoIda=" + tiempoIda
				+ ", tiempoVuelta=" + tiempoVuelta + "]";
	}

	


	
	
	
}
