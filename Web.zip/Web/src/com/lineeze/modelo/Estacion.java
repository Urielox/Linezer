package com.lineeze.modelo;


public class Estacion  {

	private int relacionId;
	private int estacionId;
	private int lineaId;
	private String estacionNombre;
	private String lineaNombre;
	

	
	public Estacion() {
	}
	public Estacion(int relacionId) {
		this.relacionId = relacionId;
	}
	public Estacion(Estacion e) {
		super();
		this.relacionId = e.getRelacionId();
		this.estacionId = e.getEstacionId();
		this.lineaId = e.getLineaId();
		this.estacionNombre = e.getEstacionNombre();
		this.lineaNombre = e.getLineaNombre();
		
	}
	public Estacion(int relacionId, int estacionId, int lineaId, String estacionNombre, String lineaNombre) {
		super();
		this.relacionId = relacionId;
		this.estacionId = estacionId;
		this.lineaId = lineaId;
		this.estacionNombre = estacionNombre;
		this.lineaNombre = lineaNombre;
	}
	public int getRelacionId() {
		return relacionId;
	}
	public void setRelacionId(int relacionId) {
		this.relacionId = relacionId;
	}
	public int getEstacionId() {
		return estacionId;
	}
	public void setEstacionId(int estacionId) {
		this.estacionId = estacionId;
	}
	public int getLineaId() {
		return lineaId;
	}
	public void setLineaId(int lineaId) {
		this.lineaId = lineaId;
	}
	public String getEstacionNombre() {
		return estacionNombre;
	}
	public void setEstacionNombre(String estacionNombre) {
		this.estacionNombre = estacionNombre;
	}
	public String getLineaNombre() {
		return lineaNombre;
	}
	public void setLineaNombre(String lineaNombre) {
		this.lineaNombre = lineaNombre;
	}
	@Override
	public String toString() {
		return "Estacion [relacionId=" + relacionId + ", estacionId=" + estacionId + ", lineaId=" + lineaId
				+ ", estacionNombre=" + estacionNombre + ", lineaNombre=" + lineaNombre + "]";
	}
	
}
