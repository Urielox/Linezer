package com.lineeze.database;

import java.sql.DriverManager;
import java.sql.Connection;


public class Conexion {
	private Connection cnx;
	private String direccion = "localhost:3306";
	private String nombreBase ="Maze";
	private String userName = "root";
	private String passw = "n0m3l0";
	public Connection crearConexion() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			cnx = DriverManager.getConnection("jdbc:mysql://"+direccion+"/"+nombreBase, userName, passw);
		
		}catch(Exception xxx) {
			xxx.getStackTrace();
		}
		return cnx;
	}
	
	public void cerrarConexion() {
		if(cnx != null) {
			try {
				cnx.close();
			}catch(Exception xxx) {
				xxx.getStackTrace();
			}
		}
	}

	public Connection getCnx() {
		return cnx;
	}
	
}